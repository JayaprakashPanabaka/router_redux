import { useState } from 'react';
import { useDispatch } from 'react-redux';
import { ACTIONS } from './bankStoreRedux.js';

const FormRedux = () => {
  const [amount, setAmount] = useState(null);
  const [name, setName] = useState('');
  const [contact, setContact] = useState(null);
  const [transId, setTransId] = useState(0);

  const dispatcher = useDispatch();

  const handleDeposit = () => {
    dispatcher({ type: ACTIONS.DEPOSIT, payload: Number(amount) });
    setAmount('');
    setTransId((prev) => prev + 1);
    dispatcher({
      type: 'TRANSACTIONS',
      payload: {
        id: transId,
        value: amount,
        type: 'Deposit',
        date: new Date(),
      },
    });
  };

  const handleWithdrawal = () => {
    dispatcher({ type: ACTIONS.WITHDRAWAL, payload: Number(amount) });
    setAmount('');
    setTransId((prev) => prev + 1);
    dispatcher({
      type: 'TRANSACTIONS',
      payload: {
        id: transId,
        value: amount,
        type: 'WIthdrawal',
        date: new Date(),
      },
    });
  };

  const handleUpdateName = () => {
    dispatcher({ type: ACTIONS.UPDATENAME, payload: name });
    setName('');
    setTransId((prev) => prev + 1);
    dispatcher({
      type: 'TRANSACTIONS',
      payload: {
        id: transId,
        value: name,
        type: 'Update Name',
        date: new Date(),
      },
    });
  };

  const handleUpdateContact = () => {
    dispatcher({ type: ACTIONS.UPDATECONTACT, payload: contact });
    setContact('');
    setTransId((prev) => prev + 1);
    dispatcher({
      type: 'TRANSACTIONS',
      payload: {
        id: transId,
        value: contact,
        type: 'Update Contact',
        date: new Date(),
      },
    });
  };

  return (
    <div>
      <h1>Account Form</h1>
      <div>
        <input
          type="number"
          placeholder="Enter Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <button
          onClick={handleDeposit}
          style={{ border: '1px solid', margin: '1rem' }}
        >
          Deposit
        </button>
        <button onClick={handleWithdrawal} style={{ border: '1px solid' }}>
          Withdraw
        </button>
      </div>

      <div>
        <input
          type="text"
          placeholder="Enter Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <button
          onClick={handleUpdateName}
          style={{ border: '1px solid', margin: '1rem' }}
        >
          Update Name
        </button>
      </div>

      <div>
        <input
          type="number"
          placeholder="Enter Contact Number"
          value={contact}
          onChange={(e) => setContact(e.target.value)}
        />
        <button
          onClick={handleUpdateContact}
          style={{ border: '1px solid', margin: '1rem' }}
        >
          Update Contact
        </button>
      </div>
    </div>
  );
};

export default FormRedux;
