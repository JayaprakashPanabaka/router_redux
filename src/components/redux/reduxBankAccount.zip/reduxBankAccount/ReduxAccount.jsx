import { useSelector } from 'react-redux';

const AccountRedux = () => {
  const accountDetails = useSelector((state) => state);
  console.log(accountDetails);

  // accountDetails = {
  // accounts: {},
  // transactions: [
  // {}, {} ,{} .......
  // ]
  // }

  return (
    <div>
      <h1>Account Information</h1>
      <h3>Account Holder</h3>
      <table>
        <thead>
          <tr>
            <th>Balance</th>
            <th>Name</th>
            <th>Contact</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{accountDetails.account.balance}</td>
            <td>{accountDetails.account.name}</td>
            <td>{accountDetails.account.contact}</td>
          </tr>
        </tbody>
      </table>

      <h3>Transaction Details</h3>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Value</th>
            <th>Type</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          {accountDetails.transactions.map((item) => {
            return (
              <tr key={item.id}>
                <td>{item.id}</td>
                <td>{item.value}</td>
                <td>{item.type}</td>
                <td>{item.date.toString()}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default AccountRedux;
