import { createStore, combineReducers } from 'redux';

export const ACTIONS = {
  DEPOSIT: 'DEPOSIT',
  WITHDRAWAL: 'WITHDRAWAL',
  UPDATENAME: 'UPDATENAME',
  UPDATECONTACT: 'UPDATECONTACT',
};

const accountHolder = {
  balance: 0,
  name: 'JP',
  contact: 8099099123,
};

const accountReducer = (state = accountHolder, action) => {
  switch (action.type) {
    case ACTIONS.DEPOSIT:
      return { ...state, balance: state.balance + action.payload };
    case ACTIONS.WITHDRAWAL:
      return { ...state, balance: state.balance - action.payload };
    case ACTIONS.UPDATENAME:
      return { ...state, name: action.payload };
    case ACTIONS.UPDATECONTACT:
      return { ...state, contact: action.payload };
    default:
      return state;
  }
};

const transactionsReducer = (state = [], action) => {
  switch (action.type) {
    case 'TRANSACTIONS':
      return [
        ...state,
        {
          id: action.payload.id,
          value: action.payload.value,
          type: action.payload.type,
          date: action.payload.date,
        },
      ];
    default:
      return state;
  }
};

const rootReducer = combineReducers({
  account: accountReducer,
  transactions: transactionsReducer,
});

export const accountStore = createStore(rootReducer);

console.log(accountStore.getState());

// accountStore.dispatch({
//   type: 'ADD_TRANSACTION',
//   payload: {
//     id: 1,
//     value: 101,
//     type: 'deposit',
//     date: '02.03.2024',
//   },
// });

// console.log(accountStore.getState());

// console.log(accountStore.getState());

// accountStore.dispatch({ type: ACTIONS.DEPOSIT, payload: 100 });

// console.log(accountStore.getState());

// accountStore.dispatch({ type: ACTIONS.WITHDRAWAL, payload: 10 });

// console.log(accountStore.getState());

// accountStore.dispatch({ type: ACTIONS.UPDATENAME, payload: 'PJP' });

// console.log(accountStore.getState());

// accountStore.dispatch({ type: ACTIONS.UPDATECONTACT, payload: 8099099234 });

// console.log(accountStore.getState());

// export default accountReducer;
